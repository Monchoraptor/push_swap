/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   list.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amoracho <amoracho@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/21 17:18:39 by amoracho          #+#    #+#             */
/*   Updated: 2022/10/06 19:48:47 by amoracho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

typedef struct s_nodo
{
	struct s_nodo	*next;
	struct s_nodo	*prev;
	void			*e;
}	t_nodo;

typedef struct s_list
{
	t_nodo	*first;
	t_nodo	*last;
	int		*size;	
}t_list;

t_list	*newlist(void)
{
	t_list	*l;

	l = (t_list *)malloc(sizeof(t_list));
	l->first = NULL;
	l->last = NULL;
	l->size = malloc(sizeof(int));
	*(l->size) = 0;
	return (l);
}

void	add(t_list *l, void *e)
{
	t_nodo	*new;

	new = malloc(sizeof(t_nodo));
	new->prev = l->last;
	new->next = NULL;
	new->e = e;
	if (*(l->size) > 0)
	{
		l->last->next = new;
		l->last = new;
		(*(l->size))++;
	}
	else
	{
		l->last = new;
		l->first = new;
		(*(l->size))++;
	}
}

void	addi(t_list *l, void *e, int i)
{
	t_nodo	*new;
	t_nodo	*aux;

	if (*(l->size) == 0)
	{
		add(l, e);
		return ;
	}	
	aux = l->first;
	while (--i > 0)
		aux = aux->next;
	new = malloc(sizeof(t_nodo));
	new->prev = aux->prev;
	new->next = aux;
	new->e = e;
	aux->prev->next = new;
	aux->prev = new;
	(*(l->size))++;
}

void	*get(t_list *l, int n)
{
	int		i;
	t_nodo	*aux;

	i = 0;
	aux = l->first;
	while (i < n)
	{
		aux = aux->next;
		i++;
	}
	return (aux->e);
}

void	addl(t_list *lo, t_list *ln)
{
	int		i;
	t_nodo	*aux;

	i = 0;
	aux = ln->first;
	while (i < *(ln->size))
	{
		add(lo, aux->e);
		aux = aux->next;
		i++;
	}
}

void	deletee(t_list *l, void *e)
{
	t_nodo	*aux;

	aux = l->first;
	while (aux)
	{
		if (aux->e == e)
		{
			aux->prev->next = aux->next;
			if (aux->next)
				aux->next->prev = aux->prev;
			if (aux->e != NULL)
				free(aux->e);
			free(aux);
		}
		aux = aux->next;
	}
	*(l->size) = *(l->size) - 1;
}

void	deleten(t_list *l, int n)
{
	t_nodo	*aux;
	int		i;

	aux = l->first;
	i = 0;
	while (i++ < n)
		aux = aux->next;
	if (n == 0)
		l->first = aux->next;
	if (aux->prev != NULL)
		aux->prev->next = aux->next;
	if (aux->next)
		aux->next->prev = aux->prev;
	if ((aux != NULL) && (aux->e != 0))
		free(aux->e);
	free(aux);
	*(l->size) = *(l->size) - 1;
}

void	deletelist(t_list *l)
{
	int	i;

	i = *(l->size);
	while (i > 0)
	{
		deleten(l, 0);
		i--;
	}
	free(l->size);
	free(l);
}

// void	printlist(t_list *l)
// {
// 	int i = 0;
// 	printf("Elementos de una lista :\n");
// 	if (*(l->size) > 0)
// 	{
// 		printf("[ %i", *((int *)get(l, i)));
// 		i++;
// 		while (i < *(l->size))
// 		{
// 			printf(" | %i", *((int *)get(l, i)));
// 			i++;
// 		}
// 		printf(" ]\n");
// 	}
// 	else
// 		printf("No hay\n");
// }

// int main()
// {
// 	t_list	*l = newlist();
// 	int		*e;
// 	int		i;

// 	i = 0;
// 	while (i < 10)
// 	{
// 		e = (int *)malloc(sizeof(int));
// 		*e = i++;
// 		add(l, e);
// 	}
// 	e = (int *)malloc(sizeof(int));
// 	*e = 2589;
// 	addi(l, e, 4);
// 	printlist(l);
// 	// printf("+%i\n", *(l->size));
// 	// printf("\n\n");
// 	deletee(l, e);
// 	// printf("+%i\n", *(l->size));

// 	printlist(l);	

// 	deleten(l, 4);
// 	// printf("tamaño%i\n", *(l->size));

// 	printlist(l);

// 	deletelist(l);

// 	printlist(l);
// 	// free(l);
// 	// system("leaks a.out");
// }