/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   list.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amoracho <amoracho@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 11:03:12 by amoracho          #+#    #+#             */
/*   Updated: 2022/10/19 11:04:37 by amoracho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIST_H
# define LIST_H

#include <stdlib.h>
#include <stdio.h>

typedef struct s_nodo
{
	struct s_nodo	*next;
	struct s_nodo	*prev;
	void			*e;
}	t_nodo;

typedef struct s_list
{
	t_nodo	*first;
	t_nodo	*last;
	int		*size;	
}t_list;

t_list	*newlist(void);
void	add(t_list *l, void *e);
void	addi(t_list *l, void *e, int i);
void	*get(t_list *l, int n);
void	addl(t_list *lo, t_list *ln);
void	deletee(t_list *l, void *e);
void	deleten(t_list *l, int n);
void	deletelist(t_list *l);

#endif