/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amoracho <amoracho@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 10:59:27 by amoracho          #+#    #+#             */
/*   Updated: 2022/10/19 21:34:00 by amoracho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"
#include <string.h>

typedef struct s_com
{
	char	*filename;
	int		argc;
	char	**args;
}	t_com;

typedef struct s_line
{
	int		ncom;
	t_list	*coms;
	char	**envp;
	char	*rinput;
	int		here_doc;
	char	*delim;
	char	*routput;
}	t_line;

int	hd(char *argv[])
{
	return ((argv[1][0] == 'h') &&
		(argv[1][1] == 'e') &&
		(argv[1][2] == 'r') &&
		(argv[1][3] == 'e') &&
		(argv[1][4] == '_') &&
		(argv[1][5] == 'd') &&
		(argv[1][6] == 'o') &&
		(argv[1][7] == 'c') &&
		(argv[1][8] == 0));
}

int path(char *s)
{
	return ((s[0] == 'P') &&
		(s[1] == 'A') &&
		(s[2] == 'T') &&
		(s[3] == 'H') &&
		(s[4] == '='));
}

char	*search_bin(char *s, t_line *line)
{
	char **splited;
	char **envp;
	char *s2;

	envp = line->envp;
	while (envp)
	{
		if (path(*envp))
		{
			splited = ft_split((*envp) + 5, ':');
			break;
		}
		envp++;
	}
	while (splited)
	{
		s2 = malloc(300 * sizeof(char));
		strcpy(s2, *splited);
		strcat(s2, "/");
		strcat(s2, s);
		if (!access(s2, X_OK))
			return (s2);
		splited++;
	}
	return NULL;
}

t_com	*parse_cmd(char *s, t_line *line)
{
	char	**splitted;
	t_com	*com;
	int		argc;

	splitted = ft_split(s, ' ');
	com = malloc(sizeof(t_com));
	com->filename = search_bin(splitted[0], line);
	// printf("\n----------\n%s\n----------\n\n", com->filename);
	printf("\n*******\n%s\n*******\n", *(splitted + 1));
	com->args = splitted;
	argc = 0;
	while (splitted[argc])
		argc++;
	com->argc = argc;
	return (com);
}

void	parse(t_line *line, int argc, char *argv[], char *envp[])
{
	int		first_arg;
	int		argsc;
	t_com	*com;

	first_arg = 2;
	line->coms = newlist();
	line->envp = envp;
	if (hd(argv))
	{
		line->here_doc = 1;
		line->delim = argv[2];
		first_arg = 3;
	}
	if (!line->here_doc)
		line->rinput = argv[1];
	argsc = 0;
	while (first_arg < argc - 1)
	{
		com = parse_cmd(argv[first_arg], line);
		add(line->coms, com);
		argsc++;
		first_arg++;
	}
	line->ncom = argsc;
	// line->ncom = 1;
	line->routput = argv[argc - 1];
}

void	children(int i, t_line *line, int pipe_in)
{
	int		pid;
	int		pip[2];
	t_com	*com;

	// printf("aaaaaaaaaaaaaaaaaaaaaaaa\n");
	if (i < line->ncom - 1)
	{
		pid = fork();
		pipe(pip);
		if (pid)
		{
			printf("Redirigimos %i a %i\n", pipe_in, STDIN_FILENO);
			dup2(pipe_in, STDIN_FILENO);
			dup2(STDOUT_FILENO, pip[1]);
			com = get(line->coms, i);
			execve(com->filename, com->args, line->envp);
		}
		else
		{
			// printf("pip[0]: %i\n", pip[0]);
			children(i + 1, line, pip[0]);
		}
	}
	else
	{
		printf("ulti\n");
		printf("Redirigimos %i a %i\n", pipe_in, STDIN_FILENO);
		dup2(pipe_in, STDIN_FILENO);
		pip[1] = open(line->routput, O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, S_IRWXU);
		printf("Redirigimos %i a %i\n", pip[1], STDOUT_FILENO);
		dup2(pip[1], STDOUT_FILENO);
		com = get(line->coms, i);
		execve(com->filename, com->args, line->envp);
	}
	
}


void	printtline(t_line *l)
{
	int	j;
	printf("ncom: %i\n", l->ncom);
	printf("comms:\n");
	int i = 0;
	while (i < l->ncom)
	{
		j = 0;
		printf("com %i : %s", i, ((t_com *)get(l->coms, i))->filename);
		while (((t_com *)get(l->coms, i))->args[j])
			printf(" \"%s\" ",((t_com *)get(l->coms, i))->args[j++]);
		printf("\n");
		i++;		
	}
	printf("here_doc: %i\n", l->here_doc);
	printf("delim: %s\n", l->delim);
	printf("rinput: %s\n", l->rinput);
	printf("routput: %s\n", l->routput);
}

int	pipex(int argc, char *argv[], char *envp[])
{
	t_line	*line;
	int		input;
	int		pid;
	int		pip[2];
	t_com	*com;

	line = malloc(sizeof(t_line));
	parse(line, argc, argv, envp);
	// printtline(line);
	
	input = open(line->rinput, O_RDONLY);
	children(0, line, input); 
	return (0);
}

int	main(int argc, char *argv[], char *envp[])
{
	// int i = 0;
	// while (i < 20)
	// 	printf("%s\n", *(envp + i++));
	// t_line *l;
	// l = malloc(sizeof(t_line));
	// parse(l, argc, argv, envp);
	// printtline(l);
	
	pipex(argc, argv, envp);

	// t_line	*line;

	// line = malloc(sizeof(t_line));
	// parse(line, argc, argv, envp);
	return (0);
}